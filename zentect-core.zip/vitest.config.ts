import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: false,
    environment: 'node',
    include: ['src/**/*.test.ts'],
    exclude: ['node_modules', 'dist', 'out'],
    server: {
      deps: {
        inline: ['better-sqlite3'],
      },
    },
  },
});
